import React, { Component } from 'react';
import Pagination from './pagination'
import CommonTable from './commonTable';
import ReportTittle from '../reportTittle';
const tablehead= [
   {
      tittle:''
   } ,
  {
     tittle:'First Name'
  } , 
  {
     tittle:'Last Name'
  } , 
  {
     tittle:'Practice'
  } , 
  {
     tittle:'Specialty'
  } ,
  {
     tittle:'city'
  } ,
  {
     tittle:'Phone No'
  }, 
   {
   tittle:'Email Address'
   }
   ,
   {
   tittle:'Postal Code'
   },
   {
   tittle:'Company Revenue'
   } 
   
];
const downlinks =  [
  {id: 1, title: 'Suggest Update', imgsrc: require("../../../assets/img/eye-border.svg")},
];
const tablevalue =[
  {
     isDropDownAvailabe: true,
     tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
  },
  {
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
},
{
   isDropDownAvailabe: true,
   tdData: ['John','doe','Smith Dentistry','Aesthetic Dentist','Columbus','(987)765-4321' ,'Williadoe148@Mail.Com' ,'364005' ,'50000000']
}
 
];
class Dashboard extends Component {
   render(){ 
      return (
         <div className="main-table-block table-section dashboard-common">
            <ReportTittle tittle=" Record List" />
            <CommonTable  tableHead={tablehead} downlinks={downlinks}  tablevalue={tablevalue} />
            <Pagination />
         </div>
       );
   }
}

export default Dashboard;