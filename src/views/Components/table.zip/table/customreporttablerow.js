import React, { Component } from 'react';
import TDropdown from './Tdropdown'
import Drp from './customreportdrpdown' 
import {
   Link
 } from "react-router-dom";
 import {history} from '../../../history';
class CustomReportTableRow extends Component {
      downlinks =  [
        { title: 'Run', imgsrc: require("../../../assets/img/file-drp.svg")},
        { title: 'Edit', imgsrc: require("../../../assets/img/edit.svg"), className:'edit_row',isClick:true,function:()=> this.onedit()},
        { title: 'Export List', imgsrc: require("../../../assets/img/export.svg")},
        { title: 'Delete', imgsrc: require("../../../assets/img/bin.svg")},      
    ];
    state = {
        isedit:true
    }
    onedit = () => {
        
        this.setState({
          isedit: !this.state.isedit
        });
      }
      Onprofile = () => {
        console.log('112')
        history.push('/adminpanel/myprofile');
      }
      render(){
       console.log(this.props.tablevalue)
          return (   
            
            <tr className={this.state.isedit ? "row-ed" : "row-ed"}>
             <TDropdown downlinks={this.downlinks} styleClass={this.state.isedit ? "drop-show" : "drop-hide"}  />
             <td className={this.state.isedit ? "edit-cl replace-drp-links-hide" : "edit-cl edit replace-drp-links-show"}  >
                  <div className="show-blk last-td">
                    <Link  className="false-row"  onClick={() => this.onedit()}>
                        <img src={require('./../../../assets/img/drp-true.svg')} className="true img-fluid" alt="true" />
                    </Link>
                    <Link href="javascript:void(0);" className="true-row ml-1">
                        <img src={require('./../../../assets/img/drp-false.svg')} className="true img-fluid" alt="false"/>
                    </Link>
                   
                  </div>
              </td>
              
              <td className={this.state.isedit ? "form-td edit-cl " : "form-td edit-cl edit"} onClick={() => this.Onprofile() }>
                  <span className="hidden">
                    Academy for sport Dentistry 
                  </span>
                  <span className="show-blk">
                    <span className="form-group mb-0">
                        <input type="text" class="form-control light-border" id="12" placeholder="User name"/>
                    </span>
                  </span>
              </td>
              <td>342</td>
              <td className="text-green">02</td>
              <td className={this.state.isedit ? "form-td edit-cl drpalter " : "form-td edit-cl drpalter edit"}>
                <span className="hidden">Daily</span>
                  <span className="show-blk">
                    <Drp/> 
                  </span>
              </td>
              <td>Thomas</td>
              <td>5/24/2020</td>
              
            </tr>
      );
   }
}

export default CustomReportTableRow;