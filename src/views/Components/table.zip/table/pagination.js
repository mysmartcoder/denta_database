import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Pagination extends Component {
  render(){
    return (      
      <div className="padding-side">
        <div className="d-flex justify-content-end align-items-center py-3 flex-column  flex-sm-row">
          <div className="rows-per-page">
            <h4 className="mb-0 mr-2 text-custom-light">Rows per page :</h4>
            <div className="users-row-select">
                <div className="form-group mb-0 ">
                  <select className="form-control" id="exampleFormControlSelect1">
                      <option>15</option>
                      <option>20</option>
                      <option>30</option>
                  </select>
                </div>
            </div>
          </div>
          <ul className="pagination align-items-center">
              <li className="page-item">
                <Link className="page-link" to="javascript:void(0);" aria-label="Previous">
                <i className="fa fa-angle-left " aria-hidden="true"></i>
                </Link>
              </li>
              <li className="page-item">
                <h4 className="mb-0">1 - 10 of 100</h4>
              </li>
              <li className="page-item">
                <Link className="page-link active" to="javascript:void(0);" aria-label="Next">
                <i className="fa fa-angle-right " aria-hidden="true"></i>
                </Link>
              </li>
          </ul>
        </div>
      </div>
    );
  }
}

export default Pagination;

