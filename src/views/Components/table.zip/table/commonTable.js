import React, { Component } from 'react';
import Thead from './tableHead';
import TDropdown from './Tdropdown'

class commonTable extends Component {
   render(){
         return (   
         <div className="table-responsive">
            <table className="table table-hover">
                  <thead>
                     <Thead tableheads={this.props.tableHead}/>
                  </thead>
               <tbody>
                  {this.props.tablevalue.map((clm,index) => (
                     <tr key={index}>
                     {clm.isDropDownAvailabe && <TDropdown downlinks={this.props.downlinks}/> }
                     {clm.tdData.map((data,index) => ( 
                        <React.Fragment>
                           <td key={index}>{data}</td>                              
                        </React.Fragment>                                                      
                     ))}
                     </tr>
                  ))}
               </tbody> 
            </table>
         </div>
      );
   }
}

export default commonTable;