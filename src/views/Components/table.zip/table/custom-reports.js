import React, { Component } from 'react';
import Thead from './tableHead';
import Pagination from './pagination'
import ReportTittle from './../reportTittle'
import CustomReportTableRow from './customreporttablerow'
const tablehead= [
  {
   tittle:''
   }, 
  {
     tittle:'Record Tittle'
  } , 
  {
     tittle:'Recorded'
  } , 
  {
     tittle:'New Contacts'
  } ,
  {
     tittle:'Alert Frequency'
  } , 
  {
     tittle:'Created By'
  } , 
  {
     tittle:'Created On'
  }
];

class Customreports extends Component {
      render(){ 
         return (   
            <div className="main-table-block table-section dashboard-common  custom-report-section">
               <ReportTittle tittle="Custom Reports List" />
               <div className="table-responsive">
                  <table className="table table-hover">
                        <thead>
                           <Thead tableheads={tablehead} />
                        </thead>
                        <tbody>
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                              <CustomReportTableRow />
                         </tbody>
                  </table>
               </div>
               <Pagination />
            </div>
        );
   }
}

export default Customreports;